class PagesController < ApplicationController
  def home
  end
  def conference 
end 
end
