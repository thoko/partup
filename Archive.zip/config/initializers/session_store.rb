# Be sure to restart your server when you modify this file.

Partup::Application.config.session_store :cookie_store, key: '_partup_session'
