# Be sure to restart your server when you modify this file.

# Your secret key is used for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!

# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
# You can use `rake secret` to generate a secure secret key.

# Make sure your secret_key_base is kept private
# if you're sharing your code publicly.
Partup::Application.config.secret_key_base = 'b1ca949ff4e01884561bcbc71867ce81bfc7c4353bfecfc323284d5df59a7c90694aa5fdc63cf3381283c26a3fa976d90eb4720a0ef95432fac070907b6d031c'
