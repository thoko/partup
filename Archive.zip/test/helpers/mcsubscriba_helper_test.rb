require 'test_helper'

class McsubscribaHelperTest < ActionView::TestCase
end
