require 'test_helper'

class McsubscribeHelperTest < ActionView::TestCase
end
