require 'test_helper'

class McsubscribeControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
